package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Customer;

public interface CustomerDao {
public void addCustomer(Customer customer);
public  void editCustomer(Customer customer);
public  void deleteCustomer(int customerId);
public Customer getCustomerById(int CustomerId);
public List<Customer> listOfCustomers();
}
