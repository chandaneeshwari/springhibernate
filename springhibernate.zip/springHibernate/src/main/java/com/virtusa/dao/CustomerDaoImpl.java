package com.virtusa.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao{
	
@Autowired
	private SessionFactory session;
	
	public void addCustomer(Customer customer) {
	 session.getCurrentSession().save(customer);
		
	}

	public void editCustomer(Customer customer) {
	
		session.getCurrentSession().update(customer);
	}

	public void deleteCustomer(int customerId) {
		
		session.getCurrentSession().delete(customerId);
	}

	public Customer getCustomerById(int customerId) {

		return session.getCurrentSession().get(Customer.class, customerId);
		 
	}

	public List<Customer> listOfCustomers() {
		
		return session.getCurrentSession().createCriteria("from Customer").list();
	}

}
