package com.virtusa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Customer {

@Id
@Column
@GeneratedValue(strategy = GenerationType.AUTO)
private String  customerId;
@Column
	private String CustomerName;
@Column
	private String mobileNumber;
@Column
	private String gender;
@Column
	private String age;
	
	public Customer() {
		
	}
	
	public Customer(String customerId, String customerName, String mobileNumber, String gender, String age) {
	
		this.customerId = customerId;
		CustomerName = customerName;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.age = age;
	}
	


	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", CustomerName=" + CustomerName + ", mobileNumber="
				+ mobileNumber + ", gender=" + gender + ", age=" + age + "]";
	}
	
}