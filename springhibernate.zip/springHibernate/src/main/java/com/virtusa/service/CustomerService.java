package com.virtusa.service;

import java.util.List;

import com.virtusa.model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);
	public  void editCustomer(Customer customer);
	public  void deleteCustomer(int customerId);
	public Customer getCustomerById(int CustomerId);
	public List<Customer> listOfCustomers();

}
