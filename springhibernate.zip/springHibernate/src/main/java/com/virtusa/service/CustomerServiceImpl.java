package com.virtusa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.dao.CustomerDao;
import com.virtusa.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
   
	@Autowired
	private CustomerDao customerDao;
	
	
	@Transactional
	public void addCustomer(Customer customer) {

customerDao.addCustomer(customer);		
	}
	@Transactional
	public void editCustomer(Customer customer) {
	
		customerDao.editCustomer(customer);
	}
	@Transactional
	public void deleteCustomer(int customerId) {
		
		customerDao.deleteCustomer(customerId);
	}
	@Transactional
	public Customer getCustomerById(int CustomerId) {
		
		return customerDao.getCustomerById(CustomerId);
	}
	@Transactional
	public List<Customer> listOfCustomers() {
		return customerDao.listOfCustomers();
	}

		
	
}
