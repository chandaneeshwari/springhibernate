package com.virtusa.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.model.Customer;
import com.virtusa.service.CustomerService;

public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping("/form")
	public String setupForm(Map<String, Object> map) {

		Customer customer = new Customer();
		map.put("customer", customer);
		map.put("customerList", customerService.listOfCustomers());
		return "customer";

	}

	@RequestMapping(value = "/customer.do", method = RequestMethod.POST)
	public String doActiions(@ModelAttribute Customer customer, BindingResult result, @RequestParam String action,
			Map<String, Object> map) {

		Customer customerdo = new Customer();

		switch (action.toLowerCase()) {
		case "add":
customerService.addCustomer(customer);
customerdo=customer;
			break;

		case "edit":
			customerService.editCustomer(customerdo);;
			customerdo=customer;
			break;

		case "delete":
			customerService.deleteCustomer(customerId);;
			customerdo= new Customer();
			break;
		case "search":
			Customer searchCustomer=customerService.getCustomerById(customer.getCustomerId());
			customerdo=customer;
			break;
		default:
			break;
		}
		return "customer";
	}
}
